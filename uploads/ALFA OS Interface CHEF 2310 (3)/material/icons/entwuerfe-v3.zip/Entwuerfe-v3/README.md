# ALFAcolor Icon, Entwürfe v3 (Autofarben)

Stand 2026-10-09. Fünf neue Ansätze, unabhängig von den verworfenen Blockfassungen. Jeder Ordner: `Ebenen/` (4 SVG, 1024², flach, ohne Maske), `komplett.svg`, `vorschau.png` (Näherung der Systemmaske), `hintergrund.txt` (Fill Solid).

Import wie im früheren Tutorial: die vier Ebenen in Icon Composer ziehen, Hintergrund als Fill Solid setzen, Reihenfolge 1 hinten, 4 vorn.

| Ordner | Idee | Hintergrund | Ebenen |
|---|---|---|---|
| A_Faecher | Farbfächer: sammeln | Stahlblau #5D8094 | Himmelblau #4FA8D8, Rosa #F0A8B8, Orange #E8731F, Gelb #F9C63C (+ Niete #111111) |
| B_A-Monogramm | A für ALFA aus Flächen | Rosa #F0A8B8 | Stahlblau, Himmelblau, Rost #D9481F, Sonnengelb #F9C63C |
| C_Pipette | Pipette: Tokens ziehen | Stahlblau #5D8094 | Gelb (Chip), Weiß #F4F7F9 (Glas), Rosa (Farbe), Rost + #111111 (Kopf) |
| D_Licht | drei Kreise, Überlappung weiß | Stahlblau #5D8094 | Rosa, Gelb, Orange, Weiß #FFFFFF (Überlappung) |
| E_Boegen | Viertelkreis-Bögen (Anklang an Aichers Regenbogenspiele) | Rosa #F0A8B8 | Stahlblau, Himmelblau, Gelb, Orange |

Farben: gemessen oder angepasst aus drei Autobildern, siehe `07-Mood-Varianten/farben-mood.txt` im früheren Paket (Stahlblau, Rosa, Rost, Orange, Sonnengelb, Himmelblau; Weiß und Schwarz ergänzt).
Glas-Settings sind noch nicht festgelegt; erst nach der Wahl.

## Briefpapier-Icon (Schwarz-Weiß, Print)
Ordner `Briefpapier-SW/`: je Entwurf `_rund` (App-Rundung, Näherung der Systemmaske) und `_quadrat`, als SVG, PDF und PNG. Nur das gestaltete Zeichen, schwarze Kontur auf Weiß, Flächen im Wechsel gefüllt und umrissen. Kein Schriftring, kein Siegel.
Hinweis: E erinnert in Schwarz-Weiß an ein WLAN-Symbol, bei D bleibt eine schwarze Sichel stehen.
