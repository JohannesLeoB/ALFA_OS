# MASTER 2910 · Übergabe Design → Code · Mail, Einstellungen, Hülle
Stand: Lieferschein 2026-10-31T04:40. Teillieferung, Freigabe Johannes 31.10.: „dann frag code per brief und liefer was du partiel liefern kannst!“ Ersetzt START-CODE-2810.md als Einstieg.

## Lesereihenfolge
0. lieferung-an-code/AN-CODE-3110.md — Fragen F1–F4 an dich, Antworten A1 (N43), A2 (N32).
1. lieferung-an-code/ABWEICHUNGEN-LIVE-2910.md — laufende App 0.1.10 gegen Bogen, L1–L6 mit Bogen- und Codezeile.
2. lieferung-an-code/AN-CODE-2810.md — was Design braucht (A1–A10, B1–B4, C1–C2, D0).
3. lieferung-an-code/ANTWORT-2810.md, OFFEN-AN-CODE-2710.md, ENTSCHEIDUNGEN-AN-CODE-2310.md, SPEC-NACHTRAG-2310.md.
4. contract/ — Vertrag: Tokens, Bauteile (97, 59 mit Zuständen), Ansichten, Texte (383), Änderungsprotokoll, LIEFERUNG.json, PRUEFUNG.txt, akte.json.
5. lieferung-an-code/symbols.json, bauteile.json, mechanik.json, motion-springs.json, settings-sections.json, fonts/.
6. Bögen im Projektstamm: ALFA Mail, ALFA Einstellungen, ALFA Shell, ALFA UI-Elemente (enthält Halten zum Bestätigen, part="confirm"; ALFA Bestaetigen gibt es nicht mehr); alfa-shell.js, alfa-bausteine.js, alfa-theme.css, TOKENBOGEN.json; Logos material/icons/.
7. entscheidungen.md — Wortlaut aller Ansagen von Johannes.

## Geändert seit 28.10. (Paket 15:40)
- Tokens neu: scale.pressButton .96, pressRow .99, pressStrong .92, overviewHot 1.012, overviewOther .988; opacity.hoverDim .88, overviewOther .55; Gruppe confirm.* jetzt in alfa-theme.css (Radieren, Zittern).
- Bauteile: 59 mit Zuständen (Farben je data-state, Hover/Drücken), vorher 0. Fundstellen aller Bauteile und Elemente neu aus den Bögen (vorher 189 von 230 veraltet).
- Bögen: Logik liest Maße über AlfaShell.tok() statt fester Zahlen (Drücken, Hover, Menü, Übersicht, Blob, Umbrüche, Fächer, Bestätigen). Bildlaufleiste nur beim Scrollen, kein seitlicher Scroll. Entwurf: Textfeld wächst mit, nur die Karte scrollt. Einstellungen: Feldzeile rechts 16; Übersicht wie Mail (gestaffelt einblenden); Stapelkarte oben gerundet wie Mail; Dunkel: Auswahlfarbe an Kachel und Zähler. Meldung: Mail var(--layer-inLane-toast), Einstellungen var(--layer-toast).
- Texte gestrichen, weil kein Gegenstück im Bogen (Bogen gilt): mail.feedback.s007, settings.label.s073/s077/s078/s084/s085, settings.section.contacts/privacy/folders.detail, settings.entry.folderSchemaSub.
- Texte: mail.action.note, mail.feedback.s012 gestrichen („Notiz anfügen“ raus, entscheidungen.md:525); Leersätze je Ordner neu (mail.empty.inbox, starred, sent, drafts, all, archive, spam, label, aus ALFA Mail ET); mail.list.empty.act „Verfassen“ gestrichen (Bogen: „Neue Mail“ = mail.action.compose).
- Offen, Entscheidung Johannes: Dunkel-Inversfarben (--c-inv, on-inv, inv-hot, inv-line, inv-field, on-inv-2/3, on-inv-line) — Bogen alfa-theme.css #2e2e2e mit weißer Schrift, TOKENBOGEN/Vertrag #f5f5f5 mit schwarzer Schrift (seit 21.10. offen, decisions.json „Klärung offen“). Bis dahin gilt nichts davon als entschieden.

## Prüfer (wörtlich)
P1 [] · P2 [] · P3 1070/1070 · P4 items: 37 of 44 done, delivery: complete · pruefung.js gruen true, fehler [] (Lauf 2026-10-31T04:40).

## Offen
- N15 Frage; N27–N31, N33 offen (Hub, wartet auf Daten von Code).
- Englisch zu mail.empty.* ergänzt (Block 23:00), Ordnernamen wie im Vertrag (Inbox, Flagged, Sent, Drafts, Archive).
- Widerspruch im Vertrag: field-row role „One 44 high row“, measures height {size.rowHeight} 36; Bogen Mail 36, Einstellungen min 44 (ALFA Einstellungen.dc.html:113). Entscheidung Johannes offen.
- 38 Bauteile ohne Zustände (Behälter oder nur in Zuständen, die im Grundbild nicht offen sind).
- Rund 58 Tokens stehen in der Logik noch als Zahl (ETAPPE-2910.md Abschnitt 4).
- Hülle: card-notice-Abstand und field-row je Ort verschieden (lieferung-an-code/_pruef-huelle-2910.json), nicht angeglichen.

## Nicht im Paket
Etappe II (ETAPPE-II/, Editoren), ARCHIV/, Studien, Farbbögen.

## Nachtrag 29.10. 23:25
- Untertitel je Abschnitt: Code liest settings.section.<name>.detail für alle 12 Abschnitte (SectionRow.swift:36, SettingsFace.swift:23, IntegrationList.swift:51). Im Vertrag stehen nur appearance, system, templates, imprint. Für die übrigen Abschnitte keinen Untertitel zeigen; gestrichen sind contacts, privacy, folders.
- Zustände (A6): formatting-bar Ruhe {color.line}, option Ruhe {color.inkSecondary}/{color.lineStrong} und gewählt {color.inverse}/{color.onInverse} (Block 23:20).
- Ohne eigene Farbe oder Zustand im Bogen (reine Anordnung, Zustände tragen die Kinder): assistant, blob-face, card-content, lane-strip, menu, message-header, notice (currentColor), recipient-input-row, search-field, search-tape, service-hero, settings-tiles, signature-editor, suggestion-list, tile-grid, tile-group, account-deck, account-title, envelope, envelope-stack, assistant-thread.
- Zustandsnamen eingetragen (Block 23:40), Farbe tragen die Kinder: confirm ruhe/frage/laeuft/fertig, content-state loading/permissionRequired/failed/noResults/empty, recipient-field collapsed/expanded, card-stack stacked/fanned, handle rest/dragging (aus data-state). recipient-list closed/open (Logik lOp: big && open ? 1 : 0) und command-group rest/hover (aO: hot ? 1 : 0): Namen von Design gesetzt, Deckkraft 0/1 ohne Token.
- Zustände (Block 00:05): assistant-activity ok {color.onInverseTertiary} / error {color.onInverse}; lane-header empty/reading/draft/confirm/fanned (HB.state); lane-content rest/tiles; row-actions rest / picked {color.lane} (R.bg); inline-confirm frage (Start von ALFA Bestaetigen); switch-glass rest {color.lane} gemischt mit {opacity.switchGlass}.
- field-row: Einstellungen setzt data-state="{{ b.state }}", b.state wird im Bogen nicht belegt → kein Zustand.
- Logikzahlen auf Token (30.10.): size.handleLength/handleLengthActive (ALFA Shell), size.blobHomeRadius, size.blobDragThreshold (Shell), size.accountClosedWidth, size.accountFanWidth (Mail), typography.weight.semibold/medium/regular (Mail wS/wSub/weight, Einstellungen weight), size.blobLidOffset (Shell), size.toggleKnobOffsetOn/Off (alfa-bausteine.js), size.overviewActionsOffset (Mail, Einstellungen).
- Hülle angeglichen (30.10.): Einstellungen Stapelkarte im Fächer h 44px → (SH − top) wie Mail, Zustandsfolge fanned vor open wie Mail.
- Übersicht-Staffel: Mail und Einstellungen jetzt motion.duration.overviewStagger (60 ms) wie alfa-bausteine.js (Entscheidung 23.10.); vorher 24 ms ohne Token.
- Gefaltete Bahn (30.10.): kein Knopf im Kopf; Klick auf den Streifen faltet auf. Rechter Streifen Mail: Antworten, Weiterleiten, Linie (shell.divider), dann Karten; vordere Karte gewählt. Einstellungen Streifen Mitte/rechts: Logos der Dienste wie Kachel.
- Token-Bindung 30.10. 04:00: Bahnköpfe (headPad*/headGap*), Kartenecken unten (radius.cardBottom), cardInset, Statuspunkt, Griff beim Ziehen (handleThicknessActive). Offene Logikzahlen: ETAPPE-2910.md Abschnitt 4.
- Neue Tokens 30.10. (Werte standen fest im Bogen): size.profileFactMinWidth 140, size.hintMaxWidth 240, ratio.fieldValueMax 0.6; size.reelTopOffset jetzt im Bogen benutzt. Im Bogen verbleibende feste Werte nur Zeichnung (Orb-Prozente) und Kantenglättung der Maske (.5px).

## Antwort auf AN-DESIGN-NACHTRAG-3010 (D1–D5)
- D1 Konto nur mit Adresse: ALFA Einstellungen accountBlocks, findServers, addAccount (Schritte adresse → suche → anmelden | manuell).
- D2 Abmelden: ALFA Mail mail.card-notice.list, mail.inline-confirm.unsubscribe (ALFA Bestaetigen), mail.text-button.unsubscribe-web; Nachricht trägt list: "oneclick" | Website (Tweak mailingList).
- D3 Später senden: ALFA Mail laterMenu, planSend, laterBack, laterNow, Ordner later, mail.card-notice.plan; Hinweis zum Versand nur bei laufendem ALFA.
- D4 Senden widerrufen: Einstellungen Verfassen (Aus, 10, 20, 30 s; Standard 10 s); Mail send() hält die Mail für die gewählte Zeit, Toast „Sendet …“ + Rückgängig.
- D5 POP: Deck zeigt nur Eingang; Einstellungen Zeile „Kopie vom Server löschen“ mit Menü Nie (Standard), Nach einem Tag, Nach einer Woche, Nach einem Monat, Beim Löschen in ALFA (settings.account.serverCopy*, wie Code ServerCopy.swift). D1: Kontotyp IMAP/POP auch im Schritt „Server gefunden“ (Code bietet beide, wenn beide gefunden).
- Texte: mail.list.*, mail.later.*, mail.toast.unsubscribed/inDrafts, settings.mail.*, settings.account.* (34, de/en).

## Nachtrag 31.10.
- ALFA Bestaetigen.dc.html gelöscht (Johannes). Halten zum Bestätigen lebt in ALFA UI-Elemente.dc.html; Mail (5×), Einstellungen (3×) binden `<dc-import name="ALFA UI-Elemente" part="confirm">`. Fundstellen umgerechnet (entscheidungen.md:586).
- Kachel Verbindungen (settings-tile, Vertrag Block 03:00): Höhe {size.settingsTileHeight} 112 (vorher fälschlich {size.menuRowHeight}), Mindestbreite {size.settingsTileMinWidth}, Radius {radius.row} 12, innen {spacing.step12}, Symbol {spacing.step44} mit {radius.row}, ohne Umriss; Logo im Symbol TILE_LOGO auf Abstandstufen (DHL step36, ClickUp/Airtable/Mail-Konten step24, Google/Happa step20 — Anteile nach Augenmaß, ohne Beleg). Fehler in c-signal, gewählt c-inv.
- Dienstkopf (service-hero): Symbol {spacing.step56}, {radius.contextMenu}, Abstand {spacing.step16}, ohne Umriss.
- material/icons/airtable-farbe.png neu (Farben aus Vorlage Johannes gemessen, entscheidungen.md:588).
- Ein Radius „22.37 %“ (App-Symbol) war ohne Beleg und ist zurückgenommen; es gibt keinen Token radius.appIcon.
- Fundstellen: 87 Element- und 86 Bauteil-Fundstellen neu aus den Bögen; Lieferschein: 31 Fundstellen inhaltlich geprüft und neu gesetzt (entscheidungen.md:605–607). T8 bleibt Platzhalter (F1).
- Logikzahlen auf Token: count.stackHeads, spacing.step8/16 (Mail), radius.blob (Shell).
- ALFA Designsystem nachgezogen (entscheidungen.md:583).
