# Brief Design → Code · 31.10.2026
Teillieferung MASTER 2910, Stand Lieferschein 2026-10-31T04:40. Freigabe Johannes 31.10.: „dann frag code per brief und liefer was du partiel liefern kannst!“

## Fragen an dich (bitte Antwort im nächsten Rückschein)
F1 · T8 Änderungsprotokoll. Ergebnis ist contract/changes.json, kein Bogen. delivery.schema.json verlangt bei done eine Zeile `*.dc.html:N`; der Eintrag ALFA Mail.dc.html:289 ist Platzhalter ohne Bedeutung (schon LIEF-T8, ENTSCHEIDUNGEN-AN-CODE-2310.md). Bitte: Dateipfade in where zulassen (z. B. `contract/changes.json`) oder where für reine Dateiergebnisse (T1, T7, T8) freigeben. Ja oder Nein?
F2 · N15 Aus Projektordner. Bitte liefern: Quelle der Projekte, Ebenen (Projekt → Ordner → Datei), Höchstzahl, Fehlertexte. Design zeichnet danach Leer, Laden, Fehler (LIEFERUNG.json N15).
F3 · Hub N27–N31, N33. Bitte Daten je Dienst: N27 Kategorien/Filter, N28 Verwalten-Felder (Clockodo, Airtable), N29 meldbare Mitteilungen je Dienst, N30 (Einstellungen:313), N31 Felder Detailbericht, N33 Kontaktquellen und ihre Zustände (spec-hub F41). Ohne diese Daten zeichnet Design nichts davon.
F4 · ABWEICHUNGEN-LIVE-2910.md L1–L6 (App 0.1.10): welche sind gebaut, welche offen? Besonders L1 Logos (project.yml:28–35 legt material/icons nicht ins Bundle) und L2 Dienstkopf.

## Antworten von Design
A1 · N43 releaseSpan 0.016 / pointerStep 0.001: kein Designwert, kein Token. Rechenschutz des Codes. Beleg: der Bogen rechnet die Zeigergeschwindigkeit mit Mindestspanne 1 ms (`Math.max(1, …)`, ALFA Shell.dc.html:194, :198) — entspricht pointerStep 0.001 s. releaseSpan steht im Bogen nicht.
A2 · N32 „Schlüssel gespeichert“/„Verwaist“: gestrichen seit 28.10. (START-CODE-2810.md „N32 gestrichen“). Im Bogen bleibt nur der Fehlersatz ALFA Einstellungen.dc.html:315.

## Offen bei Johannes (nicht an dich)
Dunkel-Inversfarben (START-CODE-2910.md, Offen) · field-row 36 gegen 44 · Dienstkopf hell: Feld weiß auf weißer Bahn ohne Haarlinie (entscheidungen.md:608).

## Neu 04:20 · Logogrößen festgelegt
Regel je Logoart, gleich in allen Feldern (ALFA Einstellungen.dc.html, TILE_LOGO / HERO_LOGO / LOGO_SIZE): vollflächig (Clockodo, Claude, sevDesk) 100 %; breit (DHL) Feld − {spacing.step8}; Bildmarke (Google, ClickUp, Airtable, Happa Happa, Mail-Konten) Feld 28 → 16, Kachel 44 → 24, Dienstkopf 56 → 32. Vorher je Logo verschieden (Google 20/28, Mail-Konten 30 px). Vertrag: components.json settings-tile / service-hero measures logoMark, logoWideInset (vollflächig = 100 % ohne Token).
