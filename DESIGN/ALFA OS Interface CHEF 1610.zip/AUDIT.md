# Audit-Auftrag · ALFA Design-Akte · Stand 17.10.2026, 21:25

Für eine fremde KI. Du prüfst, du änderst nichts. Ergebnis ist ein Bericht.

## 1 · Was das ist
Design-Entwürfe für die macOS-26-App ALFA (SwiftUI). Zwei Ansichtsbereiche (Mail, Einstellungen) in einer gemeinsamen Hülle (drei Bahnen, Blob-Menü). Code (Swift) baut nach und muss alle Maße des Entwurfs übernehmen.

## 2 · Regeln, gegen die du prüfst
1. `CLAUDE.md` (drei Regeln: Hülle nur einmal, Belegpflicht, keine ZIPs).
2. `entscheidungen.md`: einzige Quelle für Johannes' Worte, wörtlich, mit Datum. Spätere Einträge ersetzen frühere.
3. Johannes 17.10.: „CODE HAT NICHTS ZU SAGEN WAS MAßE ANGEHT … ER MUSS UNSERE ÜBERNEHMEN“.
4. Namen in Code und Tokens englisch („alles strikt englisch“, 13.10.).
5. Keine Mono-Schrift. Keine Zahlen in Ringen. Keine ⌘-Kürzel auf der UI. Farbe nie auf Aktionen, Signalrot nur für Destruktives. Fremdinhalt (Mail, PDF, Bild) nie eingefärbt. Tooltips = System (`title`).

## 3 · Quellen der Wahrheit
| Was | Datei |
|---|---|
| Alle Werte (Farben, Maße, Radien, Abstände, Schrift, Bewegung) | `TOKENBOGEN.json` |
| Rechenregeln der Hülle (Breiten, Falten, Akkordeon) | `alfa-shell.js` (Konstanten `K`, `AREA`) |
| Farben als CSS-Variablen | `alfa-theme.css` |
| Johannes' Worte | `entscheidungen.md` |
| Schrift (Geist, OFL) | `lieferung-an-code/fonts/` (geist.css, Variable 100–900, Light/Regular/Medium) |
| Rückgabe an Code | `RUECKGABE-AN-CODE.md`, `lieferung-an-code/*.json` |
| Verzeichnis der Akte | `lieferung-an-code/akte.json` |

## 4 · Die Bögen (11)
`ALFA Mail`, `ALFA Einstellungen`, `ALFA Shell`, `ALFA Bestaetigen`, `ALFA Bestaetigen Bogen`, `ALFA Shell Bogen`, `ALFA Huelle`, `ALFA Tokenbogen`, `ALFA Designsystem`, `ALFA Dienste`, `ALFA Farbsystem` (je `.dc.html`). Rolle je Bogen: `akte.json`.

Öffnen: Ordner per lokalem Webserver ausliefern (z. B. `python3 -m http.server`), dann `http://localhost:8000/ALFA%20Mail.dc.html`. Direkt per `file://` laden `fetch` und Skripte nicht. `support.js` ist die Laufzeit der Bögen, nicht Teil des Entwurfs.

## 5 · Prüfaufträge
A. **Werte-Abgleich.** Jede Zahl und Farbe in allen `.dc.html` (Inline-Styles und Logik), `alfa-shell.js`, `alfa-theme.css`, `design-system/*` gegen `TOKENBOGEN.json`. Je Fund: Wert, Datei:Zeile, Token oder „kein Token“.
B. **Belegpflicht.** Jeder Token mit `source` oder `status`: Steht das Zitat wörtlich in `entscheidungen.md`? Tokens mit `status: von Design gesetzt` gesondert auflisten.
C. **Widersprüche.** Derselbe Wert verschieden in zwei Dateien. Ein Wert gegen ein späteres Wort von Johannes. Eine Doku-Aussage gegen den Code.
D. **Hülle nur einmal.** Mail und Einstellungen: identische Hülle (Bahnen, Köpfe 44, Fuß 44, Griffe, Abstände 16/12, Radien 20/12, Blob, Menü, Bewegungen, Hover). Jede Abweichung zwischen den beiden Bögen.
E. **Nomenklatur.** Token-Namen englisch und einheitlich (camelCase im JSON, `--c-*` in CSS, `data-part` in den Bögen). Deutsche Reste, doppelte Namen für dasselbe, verwaiste Namen.
F. **Layout und Raster.** Fluchten, gleiche Abstände, Radien verschachtelt korrekt, Symbolknöpfe auf gleicher Mittellinie, 56er-Raster der Bahnen. Bei 1512 × 982 hell und dunkel.
G. **Vollständigkeit.** Tote Verweise (Dateien, Bilder, `dc-import`), Reste gelöschter Seiten (`ALFA Einstellungen Inhalt`, `ALFA Johannes entscheidet`, `ALFA Tooltip`, `PLAN.md`, `HANDOFF-ARBEITSCHAT.md`, `EINSTELLUNGEN-ABGLEICH.md`), veraltete Zahlen (224, 560, 960, 400 als Bahnbreite).

## 6 · Bekannt offen (nicht als Fehler melden, nur bestätigen)
1. `size.blobAwakeWidth` 124: Johannes „FALSCH!“, sein Wert fehlt.
2. Einstellungen: Gruppen gebaut (17.10.), Kacheln als Start nicht gebaut; Logik ist eine Kopie von Mail.
3. Mehrfachauswahl nicht entworfen.
4. `ALFA Farbsystem` nicht entschieden.
5. Von Design gesetzt (Liste in `akte.json` → `von_design_gesetzt`): `confirm.*`, `color.dark.onSignal`.
6. `github.md`: letzter Sync 13.10.
7. `ALFA Designsystem` und `design-system/*`: Farben = ersetzte Leiter „Stahl“, nur in diesem Bogen. App-Farben: `alfa-theme.css`.
8. `material/icons/s1–s7.png`, `entwuerfe-v3.zip`: Referenzmaterial, von keinem Bogen geladen.

## 7 · Ausgabe
Eine Datei `AUDIT-BERICHT.md`, eine Tabelle je Prüfauftrag A–G:

| Nr | Datei:Zeile | Befund | Beleg (Zitat oder Wert) | Schwere (blockiert Code / Fehler / Hinweis) |

Dazu eine Datei `AUDIT-WERTE.jsonl`, eine Zeile je Wert aus Auftrag A. Keine Vorschläge für neue Werte, keine Deutung von Johannes' Worten.
